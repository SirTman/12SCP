TerraxPuzzle.zip only contains the script.
Demo.zip contains a simple demo, just create a new project and overwrite the data and js directorys with the files in demo.zip

Terrax.


